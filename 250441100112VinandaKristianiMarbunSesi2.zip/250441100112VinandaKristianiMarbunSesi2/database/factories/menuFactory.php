<?php

namespace Database\Factories;

use App\Models\menu;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<menu>
 */
class menuFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $daftarmenu = [
            [
                'nama_menu' => 'Nasi_Goreng_Spesial',
                'Harga' => 25000,
            ],

            [
                'nama_menu' => 'Soto_ayam',
                'Harga' => 20000,
            ],

             [
                'nama_menu' => 'ayam_bakar',
                'Harga' => 28000,
            ],

            [
                'nama_menu' => 'Es Teh',
                'Harga' => 5000,
            ],

            [
                'nama_menu' => 'jus alpukat',
                'Harga' => 15000,
            ],
        ];

            return[
            'menu_id' => $kategori->id, 
            'nama_menu' => $menu['menu'],
            'harga' => $buku['harga'],
        ];
    }
}
