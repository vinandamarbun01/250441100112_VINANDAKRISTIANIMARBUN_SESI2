<?php

namespace Database\Factories;

use App\Models\pesanan;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<pesanan>
 */
class pesananFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
            $daftarpelanggan = [
            [
                'nama_pelanggan' => 'Budi',
                'no_meja' => 3,
                'menu_pesanan' => 'nasi_goreng _spesial',
                'jumlah_pesanan' => 2,
                'total_pesanan'=> 50000,
                'status'=>'diproses',
            ],

            [
                'nama_pelanggan' => 'Ani',
                'no_meja' => 5,
                'menu_pesanan' => 'nasi_goreng _spesial',
                'jumlah_pesanan' => 3,
                'total_pesanan'=> 45000,
                'status'=>'diproses',
            ],


        ];

            return[
            'menu_id' => $kategori->id, 
            'nama_menu' => $menu['menu'],
            'harga' => $buku['harga'],
        ];
    }
}

    

