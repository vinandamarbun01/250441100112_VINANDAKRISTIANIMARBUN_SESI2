<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pesanans', function (Blueprint $table) {
            $table->id();
            $table->bigint_unsigned('menu_id')->foreignId('menu_id')->constrained('menus')->cascadeOnDelete();
            $table->varchar(100)('nama_pelanggan')->nullable();
            $table->integer('nomor_meja')->nullable();
            $table->integer('jumlah')->minimal_1();
            $table->integer('total_harga');
            $table->Enum('status')->default();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pesanans');
    }
};
